---
name: Xamarin.Android - Snake
description: "A plain old Snake game based on a TileView (game)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - game
urlFragment: snake
---
# Snake

A plain old Snake game based on a TileView.

![Android snake game emulator screenshot](Screenshots/Snake.png)
